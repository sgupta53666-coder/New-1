import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getFoodDescription = async (foodName: string): Promise<string> => {
  try {
    const model = 'gemini-3-flash-preview';
    const prompt = `Write a short, mouth-watering, 2-sentence description for a food item named "${foodName}". Focus on taste and texture. Do not use hashtags or markdown.`;
    
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text || "Delicious food waiting for you.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "A tasty choice from our kitchen.";
  }
};
