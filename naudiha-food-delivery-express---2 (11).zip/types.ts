export enum UserRole {
  GUEST = 'GUEST',
  CUSTOMER = 'CUSTOMER',
  ADMIN = 'ADMIN'
}

export enum OrderStatus {
  PENDING = 'Pending',
  PREPARING = 'Preparing',
  OUT_FOR_DELIVERY = 'Out for Delivery',
  DELIVERED = 'Delivered',
  CANCELLED = 'Cancelled'
}

export type FoodCategory = 'Chinese' | 'Snacks' | 'Main Course' | 'Pizza' | 'Dessert' | 'Nasta';

export interface FoodItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: FoodCategory;
  isSpicy?: boolean;
}

export interface CartItem extends FoodItem {
  quantity: number;
}

export interface CustomerProfile {
  name: string;
  mobile: string;
}

export interface DeliveryDetails {
  fullName: string;
  address: string;
  phone: string;
  notes?: string;
  distanceRange?: string; // e.g., "0-2km"
}

export interface Order {
  id: string; // Firestore ID
  customerId: string; // Mobile number
  items: CartItem[];
  subtotal: number;      // Cost of items
  deliveryCharge: number; // Delivery fee
  totalAmount: number;   // subtotal + deliveryCharge
  deliveryDetails: DeliveryDetails;
  status: OrderStatus;
  timestamp: number;
}