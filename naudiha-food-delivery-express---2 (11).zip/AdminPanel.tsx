import React, { useEffect, useState } from 'react';
import { Order, OrderStatus } from '../types';
import { Package, Clock, LogOut, Phone, User, MapPin, Grid, Layers, Bike } from 'lucide-react';
import { db, collection, query, orderBy, onSnapshot, doc, updateDoc } from '../services/firebase';

interface AdminPanelProps {
  onLogout: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onLogout }) => {
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    // Real-time listener for orders
    const q = query(collection(db, 'orders'), orderBy('timestamp', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const ordersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
      setOrders(ordersData);
    });
    return () => unsubscribe();
  }, []);

  const handleUpdateStatus = async (orderId: string, status: OrderStatus) => {
    try {
      const orderRef = doc(db, 'orders', orderId);
      await updateDoc(orderRef, { status });
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };
  
  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.PENDING: return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case OrderStatus.PREPARING: return 'bg-blue-100 text-blue-800 border-blue-200';
      case OrderStatus.OUT_FOR_DELIVERY: return 'bg-purple-100 text-purple-800 border-purple-200';
      case OrderStatus.DELIVERED: return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      {/* Admin Navbar */}
      <nav className="bg-navy-900 text-white px-6 py-4 flex justify-between items-center shadow-lg sticky top-0 z-40">
        <div className="flex items-center gap-4">
          <div className="bg-brand-500 p-2 rounded-lg">
            <Package className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">Admin Dashboard</h1>
            <p className="text-xs text-navy-200">Naudiha Food Express</p>
          </div>
        </div>
        <button 
          onClick={onLogout}
          className="flex items-center gap-2 bg-navy-800 hover:bg-navy-700 px-4 py-2 rounded-lg transition-colors text-sm font-medium border border-navy-700"
        >
          <LogOut className="w-4 h-4" /> Logout
        </button>
      </nav>

      {/* Content */}
      <main className="flex-1 p-6 max-w-7xl mx-auto w-full">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between">
                <div>
                    <p className="text-gray-500 text-sm font-medium uppercase">Total Orders</p>
                    <p className="text-3xl font-bold text-navy-900 mt-1">{orders.length}</p>
                </div>
                <div className="bg-brand-50 p-3 rounded-full text-brand-600">
                    <Layers className="w-6 h-6" />
                </div>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between">
                <div>
                    <p className="text-gray-500 text-sm font-medium uppercase">Pending</p>
                    <p className="text-3xl font-bold text-yellow-600 mt-1">
                        {orders.filter(o => o.status === OrderStatus.PENDING).length}
                    </p>
                </div>
                <div className="bg-yellow-50 p-3 rounded-full text-yellow-600">
                    <Clock className="w-6 h-6" />
                </div>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between">
                <div>
                    <p className="text-gray-500 text-sm font-medium uppercase">Revenue</p>
                    <p className="text-3xl font-bold text-green-600 mt-1">
                        ₹{orders.reduce((acc, curr) => acc + curr.totalAmount, 0)}
                    </p>
                </div>
                <div className="bg-green-50 p-3 rounded-full text-green-600">
                    <div className="w-6 h-6 font-bold text-center">₹</div>
                </div>
            </div>
        </div>

        <h2 className="text-xl font-bold text-navy-900 mb-6 flex items-center gap-2">
            <Grid className="w-5 h-5 text-brand-500" /> Recent Orders
        </h2>

        {orders.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 bg-white rounded-2xl shadow-sm border border-gray-200">
            <div className="bg-gray-50 p-4 rounded-full mb-4">
                <Clock className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-500 text-lg">No orders yet. Waiting for customers...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6">
            {orders.map((order) => (
              <div key={order.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
                <div className="p-6">
                  {/* Header Row */}
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 border-b border-gray-100 pb-4">
                    <div>
                      <div className="flex items-center gap-3 mb-1">
                        <span className="text-lg font-bold text-navy-900">#{order.id.slice(0, 8)}</span>
                        <span className={`px-3 py-1 rounded-full text-xs font-bold border ${getStatusColor(order.status)}`}>
                          {order.status}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {new Date(order.timestamp).toLocaleString()}
                      </p>
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                         {/* Action Buttons based on status */}
                        {order.status === OrderStatus.PENDING && (
                            <button 
                                onClick={() => handleUpdateStatus(order.id, OrderStatus.PREPARING)}
                                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors shadow-sm"
                            >
                                Accept & Prepare
                            </button>
                        )}
                         {order.status === OrderStatus.PREPARING && (
                            <button 
                                onClick={() => handleUpdateStatus(order.id, OrderStatus.OUT_FOR_DELIVERY)}
                                className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors shadow-sm"
                            >
                                Dispatch Order
                            </button>
                        )}
                        {order.status === OrderStatus.OUT_FOR_DELIVERY && (
                            <button 
                                onClick={() => handleUpdateStatus(order.id, OrderStatus.DELIVERED)}
                                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors shadow-sm"
                            >
                                Complete Delivery
                            </button>
                        )}
                         {(order.status === OrderStatus.PENDING) && (
                            <button 
                                onClick={() => handleUpdateStatus(order.id, OrderStatus.CANCELLED)}
                                className="bg-red-50 text-red-600 hover:bg-red-100 px-4 py-2 rounded-lg text-sm font-medium transition-colors border border-red-200"
                            >
                                Cancel
                            </button>
                        )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Customer Details */}
                    <div className="bg-navy-50 p-5 rounded-xl border border-navy-100">
                      <h3 className="text-xs font-bold text-navy-500 uppercase tracking-wider mb-4 flex items-center gap-2">
                        <User className="w-4 h-4" /> Customer Details
                      </h3>
                      <div className="space-y-4">
                        <div className="flex items-start gap-3">
                           <User className="w-5 h-5 text-navy-400 mt-0.5" />
                           <div>
                               <span className="block font-semibold text-navy-900">{order.deliveryDetails.fullName}</span>
                               <span className="text-xs text-navy-500">Name</span>
                           </div>
                        </div>
                        <div className="flex items-start gap-3">
                           <Phone className="w-5 h-5 text-navy-400 mt-0.5" />
                           <div>
                                <a href={`tel:${order.deliveryDetails.phone}`} className="block font-semibold text-brand-600 hover:underline">{order.deliveryDetails.phone}</a>
                                <span className="text-xs text-navy-500">Contact</span>
                           </div>
                        </div>
                        <div className="flex items-start gap-3">
                           <MapPin className="w-5 h-5 text-navy-400 mt-0.5" />
                           <div>
                               <span className="block text-navy-800 leading-snug">{order.deliveryDetails.address}</span>
                               <span className="text-xs text-navy-500">Delivery Address</span>
                           </div>
                        </div>
                        {order.deliveryDetails.distanceRange && (
                            <div className="flex items-start gap-3">
                                <Bike className="w-5 h-5 text-navy-400 mt-0.5" />
                                <div>
                                    <span className="block text-navy-800 font-medium">{order.deliveryDetails.distanceRange} Zone</span>
                                    <span className="text-xs text-navy-500">Delivery Zone</span>
                                </div>
                            </div>
                        )}
                      </div>
                    </div>

                    {/* Order Items */}
                    <div>
                      <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-4 flex items-center gap-2">
                        <Package className="w-4 h-4" /> Order Summary
                      </h3>
                      <ul className="divide-y divide-gray-100 mb-4 max-h-48 overflow-y-auto pr-2">
                        {order.items.map((item, idx) => (
                          <li key={idx} className="py-3 flex justify-between items-center">
                            <div className="flex items-center gap-3">
                                <span className="bg-gray-100 text-gray-700 w-8 h-8 flex items-center justify-center rounded-lg text-sm font-bold border border-gray-200">
                                    {item.quantity}x
                                </span>
                                <span className="text-sm font-medium text-gray-700">{item.name}</span>
                            </div>
                            <span className="text-sm font-semibold text-gray-900">₹{(item.price * item.quantity).toFixed(2)}</span>
                          </li>
                        ))}
                      </ul>
                      
                      <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-2">
                         <div className="flex justify-between text-sm text-gray-600">
                             <span>Subtotal</span>
                             <span>₹{order.subtotal || order.totalAmount}</span>
                         </div>
                         {order.deliveryCharge !== undefined && (
                            <div className="flex justify-between text-sm text-gray-600">
                                <span>Delivery Fee</span>
                                <span>₹{order.deliveryCharge}</span>
                            </div>
                         )}
                         <div className="flex justify-between items-center pt-2 border-t border-gray-200">
                            <span className="font-bold text-gray-700">Total Amount</span>
                            <span className="font-bold text-xl text-brand-600">₹{order.totalAmount.toFixed(2)}</span>
                         </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};
